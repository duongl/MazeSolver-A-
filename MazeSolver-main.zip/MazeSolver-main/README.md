# MazeSolver
Maze solver using A star algorithm

![AStar](https://user-images.githubusercontent.com/78307937/133216378-a6ce7a28-7d2c-4adf-97de-a1eb63644a55.png)

# Output
![output](https://user-images.githubusercontent.com/78307937/133218400-ed84be79-3975-448b-99a4-e25d348290a3.png)


# Requirements:
1.Install python latest version.

2.Install pip.

3.Install simpleai.

4.Run the file .



